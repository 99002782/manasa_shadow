package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Cafeteria;
import com.example.demo.service.CafeteriaServiceImpl;



@RestController
public class CafeteriaController {

	@Autowired
	private CafeteriaServiceImpl service;
	
	 @PostMapping("/add")
	    public Cafeteria add(@RequestBody Cafeteria cafeteria) {
	        return service.save(cafeteria);
	    }

	    @PostMapping("/adds")
	    public List<Cafeteria> adds(@RequestBody List<Cafeteria> cafeteria) {
	        return service.saveall(cafeteria);
	    }

	    @GetMapping("/details")
	    public List<Cafeteria> findAll() {
	        return service.get();
	    }

//	    @GetMapping("/productById/{id}")
//	    public Cafeteria findProductById(@PathVariable int id) {
//	        return service.getProductById(id);
//	    }

//	    @GetMapping("/peoplecount/{spacetype}")
//	    public Cafeteria 
//	    @GetMapping("/students/department/{department}")
//		List<Student> getStudentByDepartment(@PathVariable("department")String department) {
//			return studentService.getStudentByDepartment(department);
//		}
//	
	    @GetMapping("/peoplecount/{spacetype}")
	    public List<Cafeteria> findByPeoplecount(@PathVariable("spacetype") Integer spacetype) {
	        return service.getPeoplecount(spacetype);
	    }
	    @GetMapping("/peoplecoun/{spacetype}")
	    public List<Cafeteria> findBySpacetype(@PathVariable("spacetype") String spacetype) {
	        return service.getSpacetype(spacetype);
	    }
   
}
