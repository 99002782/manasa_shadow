package com.example.demo.service;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.model.Cafeteria;

public interface CafeteriaService {
	
	List<Cafeteria> getPeoplecount(Integer spacetype);
//	@Query("select u from cafe where u.spacetype=:n")
//	List<Cafeteria> getSpacetype(@Param("n")String spacetype);
	List<Cafeteria> getSpacetype(String spacetype);
}
